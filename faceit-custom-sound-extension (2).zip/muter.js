// Работает внутри страницы FACEIT: глушит родные звуки сайта.
// Режим "глушить всё" включается настройкой в окошке расширения (по умолчанию включён).
(function () {
  'use strict';
  var root = document.documentElement;
  var TEXTS = ['принять', 'accept', 'match ready', 'матч найден'];
  var URL_RE = /match|ready|accept|found|queue/i;
  var lastSeen = 0;

  function muteAll() {
    return root.getAttribute('data-fcs-muteall') !== '0';
  }

  function popupVisible() {
    var btns = document.querySelectorAll('button');
    for (var i = 0; i < btns.length; i++) {
      var b = btns[i];
      var t = (b.textContent || '').trim().toLowerCase();
      if (!t || b.offsetParent === null) continue;
      for (var j = 0; j < TEXTS.length; j++) {
        if (t === TEXTS[j] || t.indexOf(TEXTS[j]) === 0) {
          lastSeen = Date.now();
          return true;
        }
      }
    }
    return Date.now() - lastSeen < 3000;
  }

  function shouldMute(el) {
    if (el instanceof HTMLVideoElement) return false; // видео не трогаем
    if (muteAll()) return true;
    var src = (el && (el.currentSrc || el.src)) || '';
    return popupVisible() || URL_RE.test(src);
  }

  // <audio> и new Audio()
  var origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function () {
    if (shouldMute(this)) {
      this.muted = true;
      this.volume = 0;
      return Promise.resolve();
    }
    return origPlay.apply(this, arguments);
  };

  // <audio autoplay> без вызова play()
  document.addEventListener('play', function (e) {
    var el = e.target;
    if (el && el.tagName === 'AUDIO' && shouldMute(el)) {
      el.muted = true;
      el.volume = 0;
      try { el.pause(); } catch (err) {}
    }
  }, true);

  // Web Audio (Howler и т.п.)
  var origStart = AudioBufferSourceNode.prototype.start;
  AudioBufferSourceNode.prototype.start = function () {
    if (muteAll() || popupVisible()) return;
    return origStart.apply(this, arguments);
  };
})();
